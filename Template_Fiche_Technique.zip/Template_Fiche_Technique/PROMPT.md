# Prompt de génération (à coller avec le contenu des fichiers du modèle)

Tu es un rédacteur technique senior. Rédige TOUJOURS en français (registre formel, administratif).

Je te fournis un projet LaTeX MODÈLE (main.tex, page_garde.tex, chapitres/*.tex). Remplis-le pour l'application décrite ci-dessous.

RÈGLES
1. Conserve EXACTEMENT les fichiers, l'ordre et la hiérarchie \chapter / \section / \subsection du modèle. Ne change pas le préambule.
2. Remplace chaque [[...]] par du contenu rédigé. Dupliquer les blocs « par rôle » (ch. 1 et ch. 3) pour chaque rôle ; supprimer les sous-sections de « Fonctionnalités Communes » que l'application n'a pas.
3. Chaque fonctionnalité du guide : Objectif, Accès, étapes (enumerate), Résultat attendu, figure avec \IfFileExists.
4. Déclarer dans l'environnement acronym tout sigle utilisé via \ac{}.
5. N'invente ni chiffres, ni versions, ni fonctionnalités : si une information manque, laisse `% À COMPLÉTER : ...`.
6. Volume cible : intro ≈ 2 p., ch.1 ≈ 8 p., ch.2 ≈ 8 p., ch.3 ≈ 40 p., conclusion + perspectives ≈ 2 p.
7. Livre chaque fichier dans un bloc de code séparé avec son chemin, puis la liste des « À COMPLÉTER ».

APPLICATION
- Nom : …  - Objet : …  - Organisme : …  - Service : …  - Année : …
- Rôles et fonctionnalités par rôle : …
- Fonctionnalités communes : …
- Stack technique, base de données, langues, thèmes : …
- Prérequis et étapes d'installation : …
- Problème métier : …
